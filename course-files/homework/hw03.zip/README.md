---
layout: default
title: Homework 3
nav_exclude: True
---

# Homework 3 Instructions
Please refer to the instructions and starter files below.

{:.summary-table}
| Starter Files: | [download here](../hw03.zip) |
| Instructions: | <a target="_blank" href="https://docs.google.com/document/d/1JTxt-HaYYwnvKv3pr_fVPHEKIJ0QXTi5BPHU6FXXpLI/edit?usp=sharing">view here</a> |
| Due: | Thursday, Jan 30th, at 11:59PM |