---
layout: default
title: Homework 2
nav_exclude: True
---

# Homework 2 Instructions
This is the beginning of a project that will last for about 4 weeks. For the first week,
you will get oriented with the Tkinter drawing module.

{:.summary-table}
| Starter Files | [download here](../hw02.zip) |
| Instructions | [download here](../hw02.zip) |
| Due | Jan 23th, at 11:59PM |
