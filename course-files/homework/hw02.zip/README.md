---
layout: default
title: Homework 2
nav_exclude: True
---

# Homework 2 Instructions
This is the beginning of a project that will last for about 4 weeks. For the first week,
you will get oriented with the Tkinter drawing module.

{:.summary-table}
| Starter Files: | [download here](../hw02.zip) |
| Instructions: | <a target="_blank" href="https://docs.google.com/document/d/1VKS-A7w8rbgnrArLbTir0QF3_DDuKNflIdqfoS09pC8/edit?usp=sharing">view here</a> |
| Due: | Thursday, Jan 23th, at 11:59PM |
