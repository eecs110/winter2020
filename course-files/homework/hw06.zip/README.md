---
layout: default
title: Homework 6
nav_exclude: True
---

# Homework 6 Instructions
* Due: Th, March 12 (11:59PM)

The goal of homework 6 is to get you to NOT procrastinate on project 2, given that it's almost a quarter of your total grade. Therefore, please turn in 20 points worth of your <a href="https://docs.google.com/document/d/1oilw3WaIedJJnklT5WXkXvolxcxO9ZyzDLMTN_hB2uw/edit?usp=sharing" target="_blank">project 2</a>. 

> **REMINDER:** Please note that your project 2 submission is due 5 days from the HW6 due data on Tu, March 17th.

What to turn in:
* A zip file of what you have so far
* In the text box, describe which of the 20 points you have implemented