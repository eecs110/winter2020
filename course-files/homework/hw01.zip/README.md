---
layout: default
title: Homework 1
nav_exclude: True
---

# Homework 1 Instructions
Install Python and Anaconda, and complete the 9 exercises. 

* Instructions available in [the Google Doc](https://drive.google.com/open?id=1UmvlrqLf05SdgVWuqb8QyFAUrqPDGjsr8EWX5ZtHC34)
* Due on Tuesday, Jan 14th, at 11:59PM
* Download the starter [main.py](main.py) file
