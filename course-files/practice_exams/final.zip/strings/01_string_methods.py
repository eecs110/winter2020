# using a string method, replace all instances of the 
# word "woodchuck" with the word "squirrel":
paragraph = '''
    How much wood could a woodchuck chuck 
    If a woodchuck could chuck wood? 
    As much wood as a woodchuck could chuck, 
    If a woodchuck could chuck wood.
'''
print(paragraph)
print(paragraph.replace('woodchuck', 'squirrel'))