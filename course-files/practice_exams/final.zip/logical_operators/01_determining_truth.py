# Note: both a and b evaluate to true because they're not 0, False, or None
a = [3, 5]
b = 22
c = 0
d = []
e = 1
f = None
if a:
    print('a evaluated to True')
else:
    print('a evaluated to False')

if b:
    print('b evaluated to True')
else:
    print('b evaluated to False')

if c:
    print('c evaluated to True')
else:
    print('c evaluated to False')

if d:
    print('d evaluated to True')
else:
    print('d evaluated to False')
    
if e:
    print('e evaluated to True')
else:
    print('e evaluated to False')

if f:
    print('f evaluated to True')
else:
    print('f evaluated to False')