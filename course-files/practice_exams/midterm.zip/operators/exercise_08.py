# Consider the following program:
# What value is stored in the variable "result"?
# What data type is the value stored in the variable "result"?

result = [48, 50, 52, 53]
measure_2 = [55, 57, 59, 60]
result = result + measure_2


print(result)
# if you ever want to know what type of data you have, use the built-in type() function:
print(type(result))  