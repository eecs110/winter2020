numbers = [65, 1800, 12, 20, 19163, 5000, 260, 0, 40, 953, 775, 67, 33]
# Challenge: write a program that finds the biggest number
# in the numbers list above