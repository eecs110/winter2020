from apis import youtube

help(youtube)