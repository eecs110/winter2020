MARIO_NOTES = [
    76, 76, 76, 72, 76, 79, 67, 72, 67, 64, 69, 71,
    70, 69, 67, 76, 79, 81, 77, 79, 76, 72, 74, 71
]

counter = 0
while counter < len(MARIO_NOTES):
    print('MARIO_NOTES[', counter, ']: ', MARIO_NOTES[counter], sep='')
    counter += 1

print('End loop. No more notes\n\n')