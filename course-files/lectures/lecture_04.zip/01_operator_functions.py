from operator import add, mul, sub, truediv, mod, floordiv, pow
# for more info, see the docs: https://docs.python.org/3/library/operator.html 

# Challenge:
# Using the functions above (no operators), write a program to 
# calculate the hypotenuse of a right triangle if the first side is 
# 5 and the second side is 12. Here's how you use the operator functions:
# add(1, 2)     -> returns 3
# pow(5, 2)     -> returns 25
# pow(25, 0.5)  -> returns 5

side_a = 5
side_b = 12
# Your code below...