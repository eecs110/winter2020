# Additional practice:
# Consider the following code:
 
print('*' * 12)
print('Hello Varun!')
print('*' * 12)
print('\n')

print('*' * 13)
print('Hello Jackie!')
print('*' * 13)
print('\n')

# Write a function that prints a message for any name 
# with enough stars to exactly match the length of the message.