for blah in range(2, 90, 10):
    print(blah)

names = ['Brian', 'Chelsea', 'Samik', 'Neha', 'Aaron']
for blah in names:
    print(blah)

for blah in [1, 2, 3, 5]:
    print(blah)
    print(names[blah])

for blah in ['a', 'b', 'c', 'd']:
    print(blah)

blah = 0
while blah < 5:
    print(blah)
    blah += 1