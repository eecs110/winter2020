'''
Recall: when we user operators...
1) the operator signified the kind of operation we wanted to perform,
2) the operands were the data we wanted to perform the operation on, and
3) after the operation, the resulting value was stored in a variable (in this case, "results")
'''

# addition:
result = 2 + 2
print(result)

# subtraction:
result = 2 - 2
print(result)

# multiplication:
result = 2 * 2
print(result)

# addition:
result = 2 / 2
print(result)