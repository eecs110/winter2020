import triangles

print('Area:', triangles.get_area(32, 23))
print('Perimeter:', triangles.get_perimeter(32, 23))
print('Hypotenuse:', triangles.get_hypotenuse(32, 23))